package com.example.flappybird

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint

class Bird(context: Context) {
    private val bitmap: Bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.bird)
    private var x: Float = 100f
    private var y: Float = 100f
    private var velocity: Float = 0f

    fun draw(canvas: Canvas) {
        canvas.drawBitmap(bitmap, x, y, null)
    }

    fun onTap() {
        velocity = -10f // Adjust this value for the Jump Height
    }

    fun update() {
        y += velocity
        velocity += 1f // Adjust this value for the Gravity Effect
    }
}
