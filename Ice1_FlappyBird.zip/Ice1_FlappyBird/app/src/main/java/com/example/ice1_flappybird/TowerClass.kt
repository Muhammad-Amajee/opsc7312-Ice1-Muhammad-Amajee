package com.example.flappybird

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint

class Tower(context: Context) {
    private val paint: Paint = Paint()

    fun draw(canvas: Canvas) {
        // Draw your tower here using canvas.drawRect or a bitmap
    }

    fun update() {
        // Update tower position
    }
}
